RANCON Marie 11309458
CHEMIER Aur�lien  10908892
DUHAMEL Arnaud 10502972

Makefile g�n�r� avec qMake et Interpolation.pro(fourni avec Qt)
Dans le dossier fichier_test : 
 - les fichiers pav contiennent des points dont on conna�t l'�valuation par la fonction
 - les fichiers eval contiennent des points pour lesquels on cherche � d�terminer l'�valuation par l'interpolation
 - les fichiers test sont des fichiers "simples" que l'on peut faire � la main
